# Example Python Code to Insert a Document 

from pymongo import MongoClient 
from bson.objectid import ObjectId 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self,username,password): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        USER = 'aacuser' 
        PASS = 'AdamAAC' 
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    # Create a method to return the next available record number for use in the create method
            
    # Complete this create method to implement the C in CRUD. 
    def create(self,data):
        if data is not None:
            try:
                self.collection.insert_one(data)
                return True 
            except Exception as e:
                print(f"Error!: {e}")
                return False
        else:
            raise ValueError("Nothing to insert")
    # Create method to implement the R in CRUD.
    def read(self,search=None):
        if search is None:
            search = {}
        try:
            records = self.collection.find(data)
            return list(records)
        except Exception as e:
            print("Error")
            return []
        
    
    def update(self,search,values):
        if search is None:
            raise ValueError("Nothing to update")
        
        try:
            updates = self.collections.update_many(search,{'$set': values})
            return updates.modified_count
        except Exception as e:
            print(f"Error: {e}")
            return 0
        
        def delete(self,search):
            if search is None:
                raise ValueError("Nothing to delete")
            try:
                deletion = self.collections.delete_many(search)
                return self.collections.deleted_count
            except Exception as e:
                print(f"Error: {e}")
                return 0